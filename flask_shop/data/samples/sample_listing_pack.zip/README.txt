成品包说明
1) 推荐根目录放 products.json，图片放 images/
2) 也可以用 products.csv：name,price,stock,introduce,images（多图用 | 分隔）
3) 或每个商品一个文件夹：纯棉T恤/info.json + 图片
4) 必须有名称和价格，缺价格的条目不会上架
5) 单包不超过 30MB，图片限 jpg/png/gif/webp
